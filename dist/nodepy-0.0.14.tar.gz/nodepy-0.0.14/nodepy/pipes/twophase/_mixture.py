from respy import Fluid

from .pressure_drop._darcy_weisbach import DarcyWeisbach

class Mixture():

	def __init__(self,pipe:Pipe,gas:Fluid,liq:Fluid):

		self.pipe = pipe
		
		self.gas = gas
		self.liq = liq

	def get(self,grate,lrate,slip:float=1.,**kwargs):

		gmass = grate*self.gas._rho
		lmass = lrate*self.liq._rho

		x = self.quality(gmass,lmass)
		visc = self.visc(self.gas.visc,self.liq.visc,x)

		a = self.alpha(grate,lrate,slip=slip)
		rho = self.rho(self.gas.rho,self.liq.rho,a)

		flow_rate = (gmass+lmass)/rho

		mixture = Fluid(visc,rho=rho)

		return DarcyWeisbach(self.pipe,mixture).get(flow_rate,**kwargs)

	@staticmethod
	def quality(massG,massL):
		"""Returns mass quality of gas."""
		return massG/(massG+massL)

	@staticmethod
	def alpha(voidG,voidL,slip:float=1.):
		"""Returns volume quality of gas."""
		return voidG/(voidG+slip*voidL)
	
	@staticmethod
	def rho(rhoG,rhoL,alpha:float=0.5):
		"""Returns mixture density based on void fraction."""
		return rhoG*alpha+rhoL*(1-alpha)
	   
	@staticmethod
	def visc(viscG,viscL,x:float=0.5):
		"""Returns mixture viscosity based on mass quality."""
		return viscG*x+viscL*(1-x)