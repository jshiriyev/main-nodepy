import numpy as np

from scipy import optimize

from ._pressure_drop import PressureDrop

class DarcyWeisbach(PressureDrop):
	"""
    Computes head loss and friction factor using the Darcy-Weisbach equation.

    Inherits from:
        PressureDrop: A base class handling pipe and fluid properties.

    Methods:
        get(flow_rate: float) -> float:
            Calculates the head loss due to friction.
        friction(flow_rate: float, laminar=2000, turbulent=4000, method="colebrook") -> float:
            Computes the Darcy friction factor based on flow regime.
        reynolds(flow_rate: float) -> float:
            Computes the Reynolds number.
        
    Static Methods:
        colebrook(Re: float, epd: float) -> float:
            Computes friction factor using the Colebrook equation.
        haaland(Re: float, epd: float) -> float:
            Computes friction factor using the Haaland equation.
        chen(Re: float, epd: float) -> float:
            Computes friction factor using the Chen equation.
    """

	def __init__(self,*args,**kwargs):
		"""
        Initializes the DarcyWeisbach class by inheriting from PressureDrop.
        
        Args:
            *args: Positional arguments passed to the parent class.
            **kwargs: Keyword arguments passed to the parent class.
        """

		super().__init__(*args,**kwargs)

	def get(self,flow_rate:float,**kwargs) -> float:
		"""Calculates the head loss due to friction using the Darcy-Weisbach equation."""
		f_D = self.friction(flow_rate,**kwargs)

		v = flow_rate/self.pipe.csa
		g = 9.80665 # Gravitational acceleration (m/s²)

		return (f_D * self.pipe.length * v**2) / (2*g*self.pipe.diam)

	def friction(self,flow_rate:float,laminar:float=2000,turbulent:float=4000,method:str="colebrook",**kwargs):
		"""Computes the Darcy-Weisbach friction factor based on the flow regime.
		
		Args:
            flow_rate (float): Volumetric flow rate in cubic meters per second (m³/s).
            laminar (float, optional): Reynolds number threshold for laminar flow (default=2000).
            turbulent (float, optional): Reynolds number threshold for turbulent flow (default=4000).
            method (str, optional): Friction factor correlation method: "colebrook", "haaland", or "chen" (default="colebrook").

        Returns:
            float: Darcy friction factor.

        Raises:
            ValueError: If the Reynolds number falls in the transition regime.

		"""
		Re = self.reynolds(flow_rate)

		if Re<laminar:
			return 64/Re

		if Re>turbulent:
			return getattr(self,method)(Re,self.pipe.epd,**kwargs)

		raise ValueError(f"Transition flow ({laminar} ≤ Re < {turbulent}) is not well defined, consider empirical interpolation.")

	def reynolds(self,flow_rate:float) -> float:
		"""Computes the Reynolds number for the given flow rate."""
		return (4*self.fluid._rho*flow_rate)/(np.pi*self.fluid._visc*self.pipe.diam)

	@staticmethod
	def colebrook(Re:float,epd:float,**kwargs) -> float:
		""" Computes the Darcy-Weisbach friction factor using the Colebrook equation."""
		inner = lambda phi,Re,epd: epd/3.7+2.51/Re/np.sqrt(phi)
		func  = lambda phi,Re,epd: 1/np.sqrt(phi)+2*np.log10(inner(phi,Re,epd))
		prime = lambda phi,Re,epd: -1/(2*phi**(3/2))*(1+2.18/(Re*inner(phi,Re,epd)))
		
		return optimize.newton(func,64/Re,prime,args=(Re,epd),**kwargs).x
		

	@staticmethod
	def haaland(Re:float,epd:float) -> float:
		"""Computes the Darcy-Weisbach friction factor using the Haaland equation."""
		return 1/(-1.8*np.log10((epd/3.7)**1.11+6.9/Re))**2

	@staticmethod
	def chen(Re:float,epd:float) -> float:
		"""Computes the Darcy-Weisbach friction factor using the Chen equation."""
		return 1/(-2*np.log10(epd/3.7065-5.0452/Re*np.log10((epd**1.1098)/2.8257+5.8506/Re**0.8981)))**2