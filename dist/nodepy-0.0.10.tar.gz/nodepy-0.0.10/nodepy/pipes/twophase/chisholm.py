class Chisholm:

    def get_x(DP_L,DP_G):
        return np.sqrt(DP_L/DP_G)

    def get_C(Re_L,Re_G):
        bool_L,bool_G = TwoPhaseLockhartMartinelli.is_laminar(Re_L,Re_G)
        
        if bool_L and bool_G:
            return 5.
        elif not bool_L and bool_G:
            return 10.
        elif bool_L and not bool_G:
            return 12.
        elif not bool_L and not bool_G:
            return 20

    def get_phi_L(x,C):
        return np.sqrt(1+C/x+1/x**2)

    def get_phi_G(x,C):
        return np.sqrt(1+C*x+x**2)