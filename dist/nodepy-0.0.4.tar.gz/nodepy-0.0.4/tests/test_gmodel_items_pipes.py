import unittest

import numpy as np

if __name__ == "__main__":
    import dirsetup

from items import pipes

class TestPipes(unittest.TestCase):

    def geometry(self):
        pass

    def singlephase(self):
        pass

    def multiphase(self):
        pass
                       
if __name__ == "__main__":

    unittest.main()
