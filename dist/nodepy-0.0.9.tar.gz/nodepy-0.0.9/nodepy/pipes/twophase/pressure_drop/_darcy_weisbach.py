import numpy as np

from scipy import optimize

from ._pressure_drop import PressureDrop

class DarcyWeisbach(PressureDrop):
	"""
	Computes head loss and friction factor using the Darcy-Weisbach equation.

	Inherits from:
		PressureDrop: A base class handling pipe and fluid properties.

	Methods:
		get(flow_rate: float) -> float:
			Calculates the head loss due to friction.
		friction(flow_rate: float, laminar=2000, turbulent=4000, method="colebrook") -> float:
			Computes the Darcy friction factor based on flow regime.
		reynolds(flow_rate: float) -> float:
			Computes the Reynolds number.
		
	Static Methods:
		colebrook(Re: float, epd: float) -> float:
			Computes friction factor using the Colebrook equation.
		haaland(Re: float, epd: float) -> float:
			Computes friction factor using the Haaland equation.
		chen(Re: float, epd: float) -> float:
			Computes friction factor using the Chen equation.
	"""

	def __init__(self,*args,**kwargs):
		"""
		Initializes the DarcyWeisbach class by inheriting from PressureDrop.
		
		Args:
			*args: Positional arguments passed to the parent class.
			**kwargs: Keyword arguments passed to the parent class.

		"""
		super().__init__(*args,**kwargs)

	def get(self,flow_rate:float|np.ndarray,**kwargs) -> float:
		"""Calculates the head loss due to friction using the Darcy-Weisbach equation."""
		fD = self.friction(flow_rate,**kwargs)

		v = flow_rate/self.pipe.csa
		g = 9.80665 # Gravitational acceleration (m/s²)

		return (fD * self.pipe.length * v**2) / (2*g*self.pipe.diam)

	def friction(self,flow_rate:float|np.ndarray,laminar:float=2000,turbulent:float=4000,method:str="colebrook",**kwargs):
		"""Computes the Darcy-Weisbach friction factor based on the flow regime.
		
		Args:
			flow_rate (float): Volumetric flow rate in cubic meters per second (m³/s).
			laminar (float, optional): Reynolds number threshold for laminar flow (default=2000).
			turbulent (float, optional): Reynolds number threshold for turbulent flow (default=4000).
			method (str, optional): Friction factor correlation method: "colebrook", "haaland", or "chen" (default="colebrook").

		Returns:
			float: Darcy friction factor.

		Raises:
			ValueError: If the Reynolds number falls in the transition regime.

		"""
		Re = self.reynolds(flow_rate)

		fD = np.empty_like(Re)

		c1 = Re<laminar
		c2 = np.logical_and(Re>=laminar,Re<=turbulent)
		c3 = Re>turbulent

		fD[c1] = 64/Re[c1]
		fD[c2] = np.nan
		fD[c3] = getattr(self,method)(Re[c3],self.pipe.epd,**kwargs)

		return

	def reynolds(self,flow_rate:float|np.ndarray) -> float:
		"""Computes the Reynolds number for the given flow rate."""
		Q = np.ravel(flow_rate)

		return (4*self.fluid._rho*Q)/(np.pi*self.fluid._visc*self.pipe.diam)

	@staticmethod
	def colebrook(Re:float|np.ndarray,epd:float,**kwargs) -> float:
		""" Computes the Darcy-Weisbach friction factor using the Colebrook equation."""
		inner = lambda phi,Re,epd: epd/3.7+2.51/Re/np.sqrt(phi)
		func  = lambda phi,Re,epd: 1/np.sqrt(phi)+2*np.log10(inner(phi,Re,epd))
		prime = lambda phi,Re,epd: -1/(2*phi**(3/2))*(1+2.18/(Re*inner(phi,Re,epd)))
		
		return optimize.newton(func,64/Re,prime,args=(Re,epd),**kwargs)
		

	@staticmethod
	def haaland(Re:float|np.ndarray,epd:float) -> float:
		"""Computes the Darcy-Weisbach friction factor using the Haaland equation."""
		return 1/(-1.8*np.log10((epd/3.7)**1.11+6.9/Re))**2

	@staticmethod
	def chen(Re:float|np.ndarray,epd:float) -> float:
		"""Computes the Darcy-Weisbach friction factor using the Chen equation."""
		return 1/(-2*np.log10(epd/3.7065-5.0452/Re*np.log10((epd**1.1098)/2.8257+5.8506/Re**0.8981)))**2