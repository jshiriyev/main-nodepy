class LockhartMartinelli:

    def is_laminar(Re_L,Re_G):
        if Re_L < 1000 and Re_G < 1000:
            return True,True
        elif Re_L < 1000 and Re_G > 2000:
            return True,False
        elif Re_L > 2000 and Re_G < 1000:
            return False,True
        elif Re_L > 2000 and Re_G > 2000:
            return False,False
        else:
            raise "Transition zone observed"
    
    def dispersed_bubbly(x):
        return 4-12*np.log(x)+28*(np.log(x))**2

    def elongated_bubbly(x):
        return 4-15*np.log(x)+26*(np.log(x))**2

    def smooth_stratified(x):
        return 2+4.5*np.log(x)+3.6*(np.log(x))**2

    def stratified_wavy(x):
        return 3+1.65*np.log(x)+0.45*(np.log(x))**2

    def slug(x):
        return 2.2+6.5*np.log(x)

    def annular_mist(x):
        return 4+2.5*np.log(x)+0.5*(np.log(x))**2