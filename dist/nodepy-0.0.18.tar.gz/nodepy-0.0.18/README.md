# nodepy

Nodal Analysis

Test the commitments (python -m unittest discover -v)