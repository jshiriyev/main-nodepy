class Mixture():

	@staticmethod
	def quality(massG,massL):
		"""Returns mass quality of gas."""
		return massG/(massG+massL)

	@staticmethod
	def alpha(voidG,voidL):
		"""Returns volume quality of gas."""
		return voidG/(voidG+voidL)
	
	@staticmethod
	def rho(rhoL,rhoG,alpha:float=0.5):
		"""Returns mixture density based on void fraction."""
		return rhoL*(1-alpha)+rhoG*alpha
	   
	@staticmethod
	def visc(viscL,viscG,x:float=0.5):
		"""Returns mixture viscosity based on mass quality."""
		return viscL*(1-x)+viscG*x